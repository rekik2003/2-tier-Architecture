package interface1;
import connexion.Connector;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class User {
	private String login;
	private String mdp;
	private static Connection c = Connector.getConnection();
	public User(String l , String m) {
		login = l;
		mdp = m ;
	}
	
	public static void afficher() {
		try {
			Statement stm = c.createStatement();
			String sql = "select * from livre";
			ResultSet result = stm.executeQuery(sql);
			while (result.next()) {
                System.out.println(
                	result.getString("ISBN")+
                	result.getString("Auteur")+
                	result.getString("Titre")+
                	result.getString("Annee")+
                	result.getString("Prix"));
            }
		}
		catch(SQLException e) {
			e.printStackTrace();
		}
	}
	
	public void cherche(File inputF, String auteur) throws IOException {
		
	}

	public String getLogin() {
		return login;
	}

	public void setLogin(String login) {
		this.login = login;
	}

	public String getMdp() {
		return mdp;
	}

	public void setMdp(String mdp) {
		this.mdp = mdp;
	}
	
}
