package interface1;

import java.io.*;
import java.util.ArrayList;

public class Client extends User{
	private ArrayList<String> livreCommander;
	
	public Client(String login, String password) {
		super(login,password);
		livreCommander = new ArrayList<String>();
	}

	public void commander(File inputF,String isbn) throws IOException {
		FileReader in = new FileReader(inputF);
		BufferedReader bufferedReader = new BufferedReader(in);
		String line= bufferedReader.readLine();
		while (line!= null)  {
			if (line.substring(0,14).equals(isbn)) {
				livreCommander.add(line);
				break;
			}
		}
		in.close();
	}
}
