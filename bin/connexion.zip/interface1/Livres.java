package interface1;

public class Livres {
	String ISBN;
	String titre;
	String auteur;
	int annee;
	int prix;
	public Livres(String iSBN, String titre, String auteur, int annee, int prix) {
		ISBN = iSBN;
		this.titre = titre;
		this.auteur = auteur;
		this.annee = annee;
		this.prix = prix;
	}	
}
