package interface1;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;

public class Admin extends User {
	public Admin(String login , String password) {
		super(login,password);
	}
	
	public void ajoute(File inputF) throws IOException {
		Scanner in = new Scanner(System.in);
		System.out.println("Entrer details : ");
		String auteur = in.next();
		String titre = in.next();
		String ISBN = in.next();
		int annee = in.nextInt();
		int prix = in.nextInt();
		in.close();
		FileReader input = new FileReader(inputF);
		FileWriter out = new FileWriter(inputF,true);
		String aux = String.format("/n%d, %s, %s, %d, %d", ISBN, auteur, titre, annee, prix);
		out.write(aux);
	}
	
	public void supprime(File inputF,String isbn) throws IOException {
		FileReader input = new FileReader(inputF);
		BufferedReader bufferedReader = new BufferedReader(input);
		String line= bufferedReader.readLine();
		FileWriter out = new FileWriter(inputF,true);
		while (line!= null) {
			if (!line.substring(0,14).equals(isbn)) {
				out.write(line);
			}
		}
	}
}
